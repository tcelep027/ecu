"""Read-only ECU detection API. No DTC table parsing or binary editing."""
import hashlib
import os
import secrets
from fastapi import FastAPI, UploadFile, File, Header, HTTPException
from ecu_detect.detector import detect

app = FastAPI(title="ECU Portal Scanner", version="0.1.0")
MAX_SIZE = 8 * 1024 * 1024

@app.get("/health")
def health():
    return {"status": "online", "mode": "read_only_ecu_detection"}

@app.post("/api/v1/analyze")
async def analyze(file: UploadFile = File(...), x_api_key: str | None = Header(default=None)):
    expected = os.getenv("ECU_API_KEY")
    if not expected or not x_api_key or not secrets.compare_digest(x_api_key, expected):
        raise HTTPException(status_code=401, detail="Unauthorized")
    if not (file.filename or "").lower().endswith(".bin"):
        raise HTTPException(status_code=400, detail="Only .bin files are supported")
    data = await file.read(MAX_SIZE + 1)
    if not data or len(data) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File must be between 1 byte and 8 MiB")
    result = detect(file.filename, data)
    supported = result.family in {"Bosch EDC15", "Bosch EDC16", "Bosch EDC17"}
    return {
        "filename": file.filename,
        "size_bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "ecu": {"designation": result.ecu, "family": result.family,
                "manufacturer": result.manufacturer, "fuel": result.fuel,
                "confidence": result.confidence},
        "supported_family": supported,
        "evidence": result.evidence[:12],
        "dtcs": [],
        "dtc_status": "not_implemented",
        "edit_supported": False,
        "message": "Signature-based ECU identification only. DTC tables are not analyzed."
    }
