"""Command-line interface for the ECU dump detector."""

from __future__ import annotations

import argparse
import json
import os
import sys

from .detector import detect, DetectionResult

_CONF_TAG = {"high": "OK", "medium": "~", "low": "?", "unknown": "x"}


def _human_size(n: int) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{n} B" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{n} B"


def _expand_paths(paths: list[str]) -> list[str]:
    files: list[str] = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                for name in names:
                    if name.lower().endswith((".bin", ".ori", ".mod", ".rom", ".hex")):
                        files.append(os.path.join(root, name))
        else:
            files.append(p)
    return files


def _result_to_dict(r: DetectionResult, show_all: bool) -> dict:
    cands = r.candidates if show_all else r.candidates[:5]
    return {
        "file": r.path,
        "size": r.size,
        "ecu": r.ecu,
        "family": r.family,
        "manufacturer": r.manufacturer,
        "fuel": r.fuel,
        "confidence": r.confidence,
        "candidates": [
            {
                "designation": c.designation,
                "family": c.family,
                "manufacturer": c.manufacturer,
                "fuel": c.fuel,
                "count": c.count,
                "score": round(c.score, 1),
                "offsets": [f"0x{o:X}" for o in c.offsets],
            }
            for c in cands
        ],
        "suppliers": r.suppliers,
        "numbers": [{"value": n, "label": lbl} for n, lbl in r.numbers],
        "evidence": r.evidence,
    }


def _print_text(r: DetectionResult, show_all: bool, show_strings: bool, data: bytes) -> None:
    tag = _CONF_TAG.get(r.confidence, "?")
    print(f"\n{'=' * 60}")
    print(f"File:         {r.path}  ({_human_size(r.size)})")
    if r.ecu:
        print(f"Detected ECU: {r.ecu}   [{tag} {r.confidence} confidence]")
        print(f"Family:       {r.family}")
    else:
        print(f"Detected ECU: <unknown>   [{tag} {r.confidence}]")
    if r.manufacturer:
        print(f"Manufacturer: {r.manufacturer}")
    if r.fuel:
        print(f"Fuel type:    {r.fuel}")

    if r.evidence:
        print("\nEvidence:")
        for line in r.evidence:
            print(f"  - {line}")

    others = (r.candidates if show_all else r.candidates[:5])[1:]
    if others:
        print("\nOther candidates:")
        for c in others:
            print(f"  - {c.designation:<14} x{c.count:<3} score={c.score:>5.1f}  ({c.family})")

    if show_strings:
        from .detector import extract_strings
        print("\nAll extracted strings (first 100):")
        for off, text in extract_strings(data)[:100]:
            print(f"  0x{off:08X}  {text}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="ecu-detect",
        description="Detect the ECU family/designation from a firmware dump (.bin).",
    )
    ap.add_argument("files", nargs="+", help="dump file(s) or directory to scan")
    ap.add_argument("--json", action="store_true", help="output JSON")
    ap.add_argument("--all", action="store_true", help="show all candidates, not just top 5")
    ap.add_argument("--strings", action="store_true", help="also dump extracted strings (text mode)")
    ap.add_argument("--min-score", type=float, default=0.0, help="drop candidates below this score")
    args = ap.parse_args(argv)

    # Avoid UnicodeEncodeError on legacy Windows consoles (cp1252).
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    except (AttributeError, ValueError):
        pass

    results = []
    exit_code = 0
    for path in _expand_paths(args.files):
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError as e:
            print(f"error: cannot read {path}: {e}", file=sys.stderr)
            exit_code = 2
            continue

        r = detect(path, data, min_score=args.min_score)
        if args.json:
            results.append(_result_to_dict(r, args.all))
        else:
            _print_text(r, args.all, args.strings, data)
        if r.ecu is None:
            exit_code = max(exit_code, 1)

    if args.json:
        json.dump(results if len(results) != 1 else results[0], sys.stdout, indent=2)
        print()

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
