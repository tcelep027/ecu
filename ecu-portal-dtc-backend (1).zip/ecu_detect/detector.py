"""Core detection engine: scan a dump, match signatures, rank candidates."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .signatures import FAMILIES, SUPPLIERS, NUMBER_PATTERNS, FamilySpec

# Match runs of printable ASCII, and runs of UTF-16LE (printable + NUL byte).
_ASCII_RE = re.compile(rb"[\x20-\x7e]{4,}")
_UTF16_RE = re.compile(rb"(?:[\x20-\x7e]\x00){4,}")


@dataclass
class Candidate:
    """A possible ECU designation and the evidence supporting it."""

    designation: str          # normalised, e.g. "EDC16C34"
    family: str               # e.g. "Bosch EDC16"
    manufacturer: str
    fuel: str
    count: int = 0            # how many times it was seen
    offsets: list[int] = field(default_factory=list)
    score: float = 0.0

    def add(self, offset: int) -> None:
        self.count += 1
        if len(self.offsets) < 8:
            self.offsets.append(offset)


@dataclass
class DetectionResult:
    path: str
    size: int
    ecu: str | None                       # best designation, if any
    family: str | None
    manufacturer: str | None
    fuel: str | None
    confidence: str                       # high | medium | low | unknown
    candidates: list[Candidate]
    suppliers: list[str]                  # supplier strings found
    numbers: list[tuple[str, str]]        # (matched number, label)
    evidence: list[str]                   # human-readable summary lines


def _normalise(token: str) -> str:
    """Uppercase and strip spaces/underscores so 'edc16 c34' -> 'EDC16C34'."""
    return re.sub(r"[\s_]+", "", token).upper()


def _specificity(designation: str) -> int:
    """More specific designations (letters followed by model digits) win ties."""
    bonus = 0
    if re.search(r"[A-Z]\d", designation):   # e.g. C34, D17
        bonus += 8
    if re.search(r"\d.*[A-Z].*\d", designation):
        bonus += 4
    bonus += min(len(designation), 12)       # longer == more specific (capped)
    return bonus


def extract_strings(data: bytes, min_len: int = 4) -> list[tuple[int, str]]:
    """Return (offset, text) for ASCII and UTF-16LE strings in the dump."""
    out: list[tuple[int, str]] = []
    for m in _ASCII_RE.finditer(data):
        if m.end() - m.start() >= min_len:
            out.append((m.start(), m.group().decode("ascii", "replace")))
    for m in _UTF16_RE.finditer(data):
        try:
            text = m.group().decode("utf-16le", "replace")
        except UnicodeDecodeError:
            continue
        if len(text) >= min_len:
            out.append((m.start(), text))
    return out


def detect(path: str, data: bytes, min_score: float = 0.0) -> DetectionResult:
    """Analyse a dump and return a ranked detection result."""
    strings = extract_strings(data)

    candidates: dict[str, Candidate] = {}
    suppliers_found: dict[str, str] = {}      # name -> fuel hint
    numbers_found: list[tuple[str, str]] = []
    number_fuel_votes: dict[str, int] = {}

    # 1) Capture ECU designations from family patterns.
    for offset, text in strings:
        for spec in FAMILIES:
            for m in spec.pattern.finditer(text):
                designation = _normalise(m.group())
                # Skip bare-family hits that carry no model info unless nothing
                # better turns up (they still register, just low specificity).
                cand = candidates.get(designation)
                if cand is None:
                    cand = Candidate(
                        designation=designation,
                        family=spec.family,
                        manufacturer=spec.manufacturer,
                        fuel=spec.fuel,
                    )
                    cand._weight = spec.weight  # type: ignore[attr-defined]
                    candidates[designation] = cand
                cand.add(offset + m.start())

    # 2) Supplier strings (corroborating).
    for name, fuel, pat in SUPPLIERS:
        for _, text in strings:
            if pat.search(text):
                suppliers_found.setdefault(name, fuel)
                break

    # 3) Number patterns (corroborating; also vote on fuel type).
    for label, fuel, pat in NUMBER_PATTERNS:
        seen = set()
        for _, text in strings:
            for m in pat.finditer(text):
                num = m.group()
                if num not in seen:
                    seen.add(num)
                    numbers_found.append((num, label))
                    if fuel:
                        number_fuel_votes[fuel] = number_fuel_votes.get(fuel, 0) + 1

    # 4) Score candidates.
    for cand in candidates.values():
        base = getattr(cand, "_weight", 50)
        score = base
        score += 10 * min(cand.count - 1, 5)          # repetition
        score += _specificity(cand.designation)        # specificity
        # Corroboration: manufacturer string present?
        if cand.manufacturer in suppliers_found:
            score += 15
        # Corroboration: a part number agreeing on fuel type?
        if cand.fuel in number_fuel_votes:
            score += 10
        cand.score = score

    ranked = sorted(candidates.values(), key=lambda c: c.score, reverse=True)
    ranked = [c for c in ranked if c.score >= min_score]

    # 5) Decide overall result + confidence.
    best = ranked[0] if ranked else None
    evidence: list[str] = []
    confidence = "unknown"
    ecu = family = manufacturer = fuel = None

    if best is not None:
        ecu = best.designation
        family = best.family
        manufacturer = best.manufacturer
        fuel = best.fuel
        specific = bool(re.search(r"[A-Z]\d|\d\.\d", best.designation))
        supported = (best.manufacturer in suppliers_found) or bool(numbers_found)
        if specific and (best.count >= 2 or supported):
            confidence = "high"
        elif specific:
            confidence = "medium"
        else:
            confidence = "low"

        loc = ", ".join(f"0x{o:X}" for o in best.offsets[:4])
        evidence.append(
            f'designation "{best.designation}" x{best.count} '
            f'(family: {best.family}) at {loc}'
        )
    elif suppliers_found or numbers_found:
        # No exact name, but we can still say something useful.
        confidence = "low"
        manufacturer = next(iter(suppliers_found), None)
        if number_fuel_votes:
            fuel = max(number_fuel_votes, key=number_fuel_votes.get)

    for name in suppliers_found:
        evidence.append(f'supplier string "{name}" present')
    for num, label in numbers_found[:6]:
        evidence.append(f"{label}: {num}")

    return DetectionResult(
        path=path,
        size=len(data),
        ecu=ecu,
        family=family,
        manufacturer=manufacturer,
        fuel=fuel,
        confidence=confidence,
        candidates=ranked,
        suppliers=list(suppliers_found),
        numbers=numbers_found,
        evidence=evidence,
    )
