"""Signature database for ECU detection.

The detector works by extracting human-readable strings from a firmware dump
and matching them against the patterns below. Two kinds of evidence are used:

  * FAMILIES      — regexes that CAPTURE the actual ECU designation. A match
                    here gives you the answer (e.g. "EDC16C34", "MED17.5.5").
  * SUPPLIERS /   — corroborating evidence. They don't name the exact ECU but
    NUMBER_PATTERNS confirm the manufacturer and/or fuel type, which raises
                    confidence and helps disambiguate.

To teach the tool a new ECU, just add a FamilySpec below. Patterns are matched
case-insensitively against extracted strings; the matched token is normalised
(uppercased, spaces/underscores stripped) to produce the reported designation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

DIESEL = "Diesel"
GASOLINE = "Gasoline"
EITHER = "Diesel/Gasoline"


@dataclass(frozen=True)
class FamilySpec:
    """A family of ECUs whose designation can be captured by a regex."""

    family: str            # human label, e.g. "Bosch EDC16"
    manufacturer: str
    fuel: str
    pattern: re.Pattern    # must match the full designation token
    weight: int = 50       # base score contributed by a match


def _p(rx: str) -> re.Pattern:
    return re.compile(rx, re.IGNORECASE)


def _fam(core: str) -> re.Pattern:
    """Build a family-designation pattern.

    Wraps ``core`` in alphanumeric boundaries so that separators commonly used
    in real ECU labels — space, underscore, slash — count as token edges
    (e.g. ``32/1/EDC17_C41/11`` -> ``EDC17_C41``). Inside ``core`` use
    ``[\\s_]?`` for optional internal separators; they are stripped during
    normalisation.
    """
    return re.compile(rf"(?<![A-Za-z0-9]){core}(?![A-Za-z0-9])", re.IGNORECASE)


# ---------------------------------------------------------------------------
# ECU family designation patterns (the part that actually names the ECU).
#
# Patterns deliberately allow an optional space between segments so that
# "EDC16 C34" still matches; normalisation removes it afterwards.
# ---------------------------------------------------------------------------
FAMILIES: list[FamilySpec] = [
    # --- Bosch diesel (EDC) ---
    FamilySpec("Bosch EDC15", "Bosch", DIESEL,
               _fam(r"EDC[\s_]?15[\s_]?[A-Z]{0,3}[\s_]?\+?\d{0,3}\+?")),
    FamilySpec("Bosch EDC16", "Bosch", DIESEL,
               _fam(r"EDC[\s_]?16[\s_]?[A-Z]{0,3}[\s_]?\d{0,3}")),
    FamilySpec("Bosch EDC17", "Bosch", DIESEL,
               _fam(r"EDC[\s_]?17[\s_]?[A-Z]{0,3}[\s_]?\d{0,3}")),
    FamilySpec("Bosch MEDC17", "Bosch", DIESEL,
               _fam(r"MEDC[\s_]?17[\s_]?[A-Z]{0,3}[\s_]?\d{0,3}")),

    # --- Bosch gasoline (ME / MED / MEV / ME17 ...) ---
    FamilySpec("Bosch Motronic ME7", "Bosch", GASOLINE,
               _fam(r"ME[\s_]?7\.\d{1,2}(?:\.\d{1,2})?")),
    FamilySpec("Bosch Motronic ME9", "Bosch", GASOLINE,
               _fam(r"ME[\s_]?9\.\d{1,2}(?:\.\d{1,2})?")),
    FamilySpec("Bosch MED9", "Bosch", GASOLINE,
               _fam(r"MED[\s_]?9\.\d{1,2}(?:\.\d{1,2})?")),
    # ME17 / MED17 / MEV17 / MEVD17 / MEDG17 ... with optional .x.y.z or _x_y
    FamilySpec("Bosch ME(D)17", "Bosch", GASOLINE,
               _fam(r"ME[A-Z]{0,3}[\s_]?17(?:[._]\d{1,2}){0,3}")),
    # Newer generation: MG1 (gasoline), MD1 (diesel)
    FamilySpec("Bosch MG1", "Bosch", GASOLINE,
               _fam(r"MG1[\s_]?[A-Z]{1,3}\d{2,3}")),
    FamilySpec("Bosch MD1", "Bosch", DIESEL,
               _fam(r"MD1[\s_]?[A-Z]{1,3}\d{2,3}")),

    # --- Siemens / Continental / VDO ---
    FamilySpec("Continental/Siemens SIMOS", "Continental/Siemens", GASOLINE,
               _fam(r"SIMOS[\s_]?\d{1,2}(?:\.\d{1,2})?")),
    FamilySpec("Continental/Siemens PCR", "Continental/Siemens", DIESEL,
               _fam(r"PCR[\s_]?\d\.\d")),
    FamilySpec("Continental/Siemens SID", "Continental/Siemens", DIESEL,
               _fam(r"SID[\s_]?\d{3}[A-Z0-9]{0,4}")),
    FamilySpec("Continental/Siemens EMS", "Continental/Siemens", GASOLINE,
               _fam(r"EMS[\s_]?\d{3,4}[A-Z]?")),
    # BMW Siemens/Continental: MSV70/80, MSD80/81/85/87, MSS60/65...
    FamilySpec("Siemens/Continental MSx (BMW)", "Continental/Siemens", GASOLINE,
               _fam(r"MS[VSD]\d{2}")),

    # --- Delphi ---
    FamilySpec("Delphi DCM", "Delphi", DIESEL,
               _fam(r"DCM[\s_]?\d\.\d")),
    FamilySpec("Delphi CRD", "Delphi", DIESEL,
               _fam(r"CRD[\s_]?\d{1,2}(?:\.\d)?")),
    FamilySpec("Delphi MT (gasoline)", "Delphi", GASOLINE,
               _fam(r"MT[\s_]?\d{2}[A-Z]?")),

    # --- Magneti Marelli ---
    FamilySpec("Magneti Marelli MJD (diesel)", "Magneti Marelli", DIESEL,
               _fam(r"MJD[\s_]?\d[A-Z]{0,3}\d{0,2}(?:\.\d)?")),
    FamilySpec("Magneti Marelli IAW", "Magneti Marelli", GASOLINE,
               _fam(r"IAW[\s_]?\d?[A-Z]{1,3}\d?")),

    # --- Denso ---
    FamilySpec("Denso", "Denso", EITHER,
               _fam(r"DENSO[\s\-_]?\d{2,}[A-Z0-9]*")),
]


# ---------------------------------------------------------------------------
# Supplier / manufacturer strings. Corroborating evidence only.
# ---------------------------------------------------------------------------
SUPPLIERS: list[tuple[str, str, re.Pattern]] = [
    ("Bosch", DIESEL,   _p(r"\bBOSCH\b")),
    ("Delphi", "",      _p(r"\bDELPHI\b")),
    ("Continental/Siemens", "", _p(r"\b(?:SIEMENS|CONTINENTAL|VDO)\b")),
    ("Magneti Marelli", "", _p(r"\b(?:MAGNETI[\s\-]?MARELLI|MARELLI)\b")),
    ("Denso", "",       _p(r"\bDENSO\b")),
    ("Hitachi", "",     _p(r"\bHITACHI\b")),
    ("Visteon", "",     _p(r"\bVISTEON\b")),
    ("Valeo", "",       _p(r"\bVALEO\b")),
    ("Sagem", "",       _p(r"\bSAGEM\b")),
    ("Kefico", "",      _p(r"\bKEFICO\b")),
    ("Temic", "",       _p(r"\bTEMIC\b")),
]


# ---------------------------------------------------------------------------
# Manufacturer part / software numbers. Corroborating evidence only.
# Each entry: (label, fuel_hint, pattern). fuel_hint may be "" (unknown).
# ---------------------------------------------------------------------------
NUMBER_PATTERNS: list[tuple[str, str, re.Pattern]] = [
    # Bosch 10-digit numbers. 0281 -> diesel EDC control unit,
    # 0261 -> gasoline Motronic control unit, 0986 -> spare/exchange.
    ("Bosch part no. 0281xxxxxx (diesel ctrl unit)", DIESEL,
     _p(r"\b0281\d{6}\b")),
    ("Bosch part no. 0261xxxxxx (gasoline ctrl unit)", GASOLINE,
     _p(r"\b0261\d{6}\b")),
    ("Bosch part no. 0986xxxxxx", "",
     _p(r"\b0986\d{6}\b")),
    # Bosch software/dataset numbers (1037..., 1039...).
    ("Bosch software no. 103xxxxxxx", "",
     _p(r"\b103[0-9]\d{6}\b")),
]
