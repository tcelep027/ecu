"""ECU dump analyzer — detect the ECU family/designation from a firmware .bin."""

from .detector import detect, DetectionResult, Candidate
from .signatures import FAMILIES, SUPPLIERS, NUMBER_PATTERNS

__all__ = [
    "detect",
    "DetectionResult",
    "Candidate",
    "FAMILIES",
    "SUPPLIERS",
    "NUMBER_PATTERNS",
]

__version__ = "0.1.0"
