"""Tests for the ECU detector using synthetic dumps."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ecu_detect.detector import detect, extract_strings  # noqa: E402


def _dump(*strings: str, size: int = 4096) -> bytes:
    """Build a fake firmware blob: random-ish padding with strings sprinkled in."""
    buf = bytearray(b"\x00\xff" * (size // 2))
    pos = 100
    for s in strings:
        enc = s.encode("ascii")
        buf[pos:pos + len(enc)] = enc
        pos += len(enc) + 50
    return bytes(buf)


def test_edc16c34_diesel():
    data = _dump("EDC16C34", "BOSCH", "0281013456", "1037387654")
    r = detect("fake.bin", data)
    assert r.ecu == "EDC16C34"
    assert r.manufacturer == "Bosch"
    assert r.fuel == "Diesel"
    assert r.confidence == "high"


def test_edc17cp20():
    data = _dump("EDC17CP20", "BOSCH")
    r = detect("fake.bin", data)
    assert r.ecu == "EDC17CP20"
    assert r.family == "Bosch EDC17"


def test_med17_gasoline():
    data = _dump("MED17.5.5", "BOSCH", "0261S03456")
    r = detect("fake.bin", data)
    assert r.ecu == "MED17.5.5"
    assert r.fuel == "Gasoline"


def test_simos_continental():
    data = _dump("SIMOS18.1", "CONTINENTAL")
    r = detect("fake.bin", data)
    assert r.ecu == "SIMOS18.1"
    assert r.manufacturer == "Continental/Siemens"


def test_sid_diesel():
    data = _dump("SID807EVO", "SIEMENS")
    r = detect("fake.bin", data)
    assert r.ecu == "SID807EVO"
    assert r.fuel == "Diesel"


def test_delphi_dcm():
    data = _dump("DCM3.7", "DELPHI")
    r = detect("fake.bin", data)
    assert r.ecu == "DCM3.7"
    assert r.manufacturer == "Delphi"


def test_spaced_designation_normalised():
    data = _dump("EDC16 C34")
    r = detect("fake.bin", data)
    assert r.ecu == "EDC16C34"


def test_utf16le_strings():
    name = "EDC17C54".encode("utf-16le")
    data = bytearray(b"\x00" * 4096)
    data[200:200 + len(name)] = name
    r = detect("fake.bin", bytes(data))
    assert r.ecu == "EDC17C54"


def test_unknown_when_nothing_matches():
    data = bytes(range(256)) * 16
    r = detect("fake.bin", data)
    assert r.ecu is None
    assert r.confidence in ("unknown", "low")


def test_best_candidate_is_most_specific():
    # Both a bare family and a specific model present; specific should win.
    data = _dump("EDC16", "EDC16C34", "EDC16C34", "BOSCH")
    r = detect("fake.bin", data)
    assert r.ecu == "EDC16C34"


if __name__ == "__main__":
    import traceback

    funcs = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for fn in funcs:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except Exception:
            failed += 1
            print(f"FAIL  {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(funcs) - failed}/{len(funcs)} passed")
    sys.exit(1 if failed else 0)
