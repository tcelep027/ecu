# ecu-detect

Detect the **ECU family / designation** from a firmware dump (`.bin`).

Give it a dump and it tells you what ECU it is, e.g.:

```
$ ecu-detect dump.bin
============================================================
File:         dump.bin  (2.0 MB)
Detected ECU: EDC16C34   [OK high confidence]
Family:       Bosch EDC16
Manufacturer: Bosch
Fuel type:    Diesel

Evidence:
  - designation "EDC16C34" x2 (family: Bosch EDC16) at 0x3E8, 0x711
  - supplier string "Bosch" present
  - Bosch part no. 0281xxxxxx (diesel ctrl unit): 0281013456
```

## How it works

ECU firmware almost always carries identifying strings baked into the binary.
`ecu-detect`:

1. **Extracts strings** — runs of printable ASCII and UTF‑16LE text, with offsets.
2. **Matches signatures** — regexes that *capture the actual ECU designation*
   (`EDC16C34`, `EDC17CP20`, `MED17.5.5`, `SIMOS18.1`, `SID807`, `DCM3.7`, …),
   plus corroborating evidence: supplier strings (`BOSCH`, `DELPHI`, …) and
   manufacturer part numbers (`0281…` diesel, `0261…` gasoline).
3. **Scores & ranks** candidates by specificity, repetition, and corroboration,
   then reports the best one with a confidence level.

It is signature-based, so it is only as good as its database — but the database
is trivial to extend (see below). No third-party dependencies; Python 3.10+.

## Usage

```bash
# No install needed — run as a module:
python -m ecu_detect dump.bin

# Or install the console command:
pip install -e .
ecu-detect dump.bin

# Options
ecu-detect dump.bin --json          # machine-readable output
ecu-detect dumps/ --all             # scan a folder, show every candidate
ecu-detect dump.bin --strings       # also dump the extracted strings
ecu-detect dump.bin --min-score 60  # only keep strong candidates
```

Exit code is `0` when an ECU is identified, `1` when nothing matched, `2` on read errors.

## Supported families (current database)

Bosch EDC15/16/17, MEDC17, ME7/ME9, MED9, ME(D/V)17, MG1/MD1 ·
Continental/Siemens SIMOS, PCR, SID, EMS, MSx (BMW) ·
Delphi DCM, CRD, MT · Magneti Marelli MJD, IAW · Denso.

## Extending the database

Add a `FamilySpec` to [`ecu_detect/signatures.py`](ecu_detect/signatures.py):

```python
FamilySpec("Bosch EDC17", "Bosch", DIESEL,
           _p(r"\bEDC\s?17\s?[A-Z]{0,3}\s?\d{0,3}\b")),
```

The regex should match the full designation token; it is normalised
(uppercased, spaces stripped) into the reported name. Supplier strings and
part-number patterns live in the same file.

## Tests

```bash
python tests/test_detector.py
```

## Caveats

- Detection relies on identifying strings being present and not encrypted/compressed.
  Some dumps (especially encrypted reads or partial flash regions) won't contain them.
- A confident family match (e.g. `EDC17`) with no model digits is reported at lower
  confidence — the binary named the family but not the exact variant.
- Intended for legitimate diagnostics, repair, and research on dumps you are authorised to analyse.
