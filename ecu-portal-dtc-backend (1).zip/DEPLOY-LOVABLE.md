# ECU-Portal — installatie

## 1. GitHub
Upload de **inhoud** van deze map naar een private GitHub-repository. Commit nooit API-sleutels of klantbestanden.

## 2. Render
New > Web Service > verbind de repository. Render leest `render.yaml` als je Blueprint kiest; anders gebruik:
- Build: `pip install -r requirements.txt`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Secret `ECU_API_KEY`: sterke willekeurige waarde, uitsluitend server-side.

Test `https://<jouw-render-url>/health`.

## 3. Lovable
Plak dit in Lovable:

> Voeg aan mijn bestaande ECU-Portal-website een pagina `/dtc-editor` toe. Gebruik bestaande login en huisstijl. Bouw een upload voor .bin-bestanden (maximaal 8 MiB) en toon de ECU-designation, familie, fabrikant, brandstof, confidence en evidence. Maak een geauthenticeerde Lovable Cloud Edge Function `ecu-analyze`. Die controleert de ingelogde gebruiker, valideert het bestand, en stuurt de bytes als multipart/form-data naar `${ECU_API_URL}/api/v1/analyze` met header `x-api-key: ${ECU_API_KEY}`. Bewaar beide waarden uitsluitend als server-side secrets; nooit in frontendcode. Toon het API-antwoord letterlijk en toon expliciet 'DTC-analyse nog niet beschikbaar' als `dtc_status` gelijk is aan `not_implemented`. Geen demo-DTC's, geen editor- of downloadknop. Log geen ruwe BIN-data. Voeg foutafhandeling, limieten en rate limiting toe.

Stel in Lovable secrets in:
- `ECU_API_URL`: je echte Render-service-URL zonder afsluitende slash
- `ECU_API_KEY`: exact dezelfde sleutel als op Render

## 4. Wat werkt / wat niet
- WEL: echte signature-gebaseerde ECU-identificatie op basis van de meegeleverde `ecu_detect`-module.
- NIET: DTC-codes uitlezen, ECU-softwareversie betrouwbaar bepalen, checksum corrigeren, DTC's wijzigen of flashbare bestanden genereren.
- Herkenning kan fout zijn bij gedeeltelijke, versleutelde of gecomprimeerde dumps.

## 5. Testen
`python tests/test_detector.py` en `python -m compileall -q .`
